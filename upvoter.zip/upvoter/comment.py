from seleniumwire import webdriver
from selenium.webdriver.chrome.options import Options
import time
from random import randint, choice

with open('cred.txt', 'r') as f:
    for line in f.readlines():
        user_v, pass_v = line.split(' ')


def comment_p(username, password, PROXY, cmt, link):
    opt = {'proxy':
    {
        'https':f'socks5://{user_v}:{pass_v}@{PROXY}',
        'no_proxy':'localhost,127.0.0.1,dev_server:8080'}
    }
    
    options = Options()
    options.add_argument("--incognito")
    options.add_argument("start-maximized")
    options.add_argument("--disable-blink-features")
    options.add_argument("--disable-blink-features")
    options.add_argument("--disable-blink-features=AutomationControlled")

    driver = webdriver.Chrome(executable_path='./chromedriver', options=options, seleniumwire_options=opt)
    driver.get('https://old.reddit.com')
    time.sleep(randint(1,5))
    driver.find_element_by_name('user').send_keys(username)
    time.sleep(randint(1,5))
    driver.find_element_by_name('passwd').send_keys(password)
    time.sleep(randint(5,10))
    try:
        driver.find_element_by_class_name('btn').click()
        time.sleep(1)
    except:
        pass

    driver.execute_script("window.open('about:blank', 'tab2');")
    time.sleep(2)
    driver.switch_to.window('tab2')
    time.sleep(0.5)
    driver.get(link)
    time.sleep(randint(5, 10))
    driver.find_element_by_name('text').send_keys(cmt)
    time.sleep(randint(1, 5))
    try:
        driver.find_element_by_class_name('save').click()
        time.sleep(3)
    except:pass

    driver.delete_all_cookies()
    driver.quit()

cmts = []

with open('comment.txt', 'r') as f:
	for line in f.readlines():
		cmts.append(line)

proxy = []

with open('proxy.txt', 'r') as f:
	for line in f.readlines():
		proxy.append(line)

with open('test.txt', 'r') as f:
	loin = f.readlines()
	i = 0
	vnk = input("Enter link: ")
    link = vnk.replace("https://www", "https://old")
	for cmt in cmts:
		username, password = choice(loin).split(' ')
		comment_p(username, password, proxy[i], cmt, link)
		i += 1
		time.sleep(randint(60, 120))


# with open('test.txt', 'r') as f:
# 	# loin = f.readlines()
# 	# i = 0
# 	# vnk = input("Enter link: ")
#     link = str(input("Enter link: ")).replace("https://www", "https://old")
#     for cmt in cmts:
#         username, password = choice(loin).split(' ')
#         comment_p(username, password, proxy[i], cmt, link)
#         i += 1
#         time.sleep(randint(60, 120))
