import time, names, requests, string
from random import randint
import random
from seleniumwire import webdriver
from selenium.webdriver.chrome.options import Options
import threading, queue
from random_user_agent.user_agent import UserAgent
from random_user_agent.params import SoftwareName, OperatingSystem
from selenium_stealth import stealth

# user_v = '7PLwk9zH36H68SK4nwiTgFNW'
# pass_v = 'SoWr1BBWKh5s3KoEt8fZrFjT'

with open('cred.txt', 'r') as f:
    for line in f.readlines():
        user_v, pass_v = line.split(' ')

def generateUser():
	#generates random username and password
	username = names.get_first_name()
	username += ''.join(str(randint(0,9))for i in range(randint(5,20)))
	password = ''.join(random.choice(string.ascii_letters+string.digits) for i in range(randint(10,20)))

	return username, password


def gets(username, password, PROXY):
    try:

        # desired_capabilities = webdriver.DesiredCapabilities.CHROME.copy()
        # desired_capabilities['proxy'] = {
        #    "httpProxy":PROXY,
        #    "ftpProxy":PROXY,
        #    "sslProxy":PROXY,
        #     "proxyType":"MANUAL",
        #     "noProxy":[],
        #     "class": "org.openqa.selenium.Proxy",
        #     "autodetect": False
        # }

        opt = {'proxy':
        {
            'https':f'socks5://{user_v}:{pass_v}@{PROXY}',
            'no_proxy':'localhost,127.0.0.1,dev_server:8080'}
        }

        software_names = [SoftwareName.CHROME.value]
        operating_systems = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]   

        user_agent_rotator = UserAgent(software_names=software_names, operating_systems=operating_systems, limit=100)

        useragent = user_agent_rotator.get_random_user_agent()

        options = Options()
        options.add_argument("--incognito")
        #options.add_argument(f'user-agent={useragent}')
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option('useAutomationExtension', False)
        options.add_argument("start-maximized")
        options.add_argument("--disable-blink-features")
        options.add_argument("--disable-blink-features=AutomationControlled")



        driver = webdriver.Chrome(executable_path='./chromedriver', options=options, seleniumwire_options=opt)
        stealth(driver,
            languages=["en-US", "en"],
            user_agent=useragent,
            vendor="Google Inc.",
            platform="Win32",
            webgl_vendor="Intel Inc.",
            renderer="Intel Iris OpenGL Engine",
            fix_hairline=True,
        )

        # driver.delete_all_cookies()
        driver.get("https://old.reddit.com/register")
        time.sleep(randint(1, 5))

        print('Entering username...')
        time.sleep(randint(1,5))
        driver.find_element_by_id('user_reg').click()
        driver.find_element_by_id('user_reg').send_keys(username)

        print('Entering in password...')
        time.sleep(randint(1,5))
        driver.find_element_by_id('passwd_reg').click()
        driver.find_element_by_id('passwd_reg').send_keys(password)

        print('Entering in password...')
        time.sleep(randint(2,5))
        driver.find_element_by_id('passwd2_reg').click()
        driver.find_element_by_id('passwd2_reg').send_keys(password)
        time.sleep(2)

        print("Getting email")
        driver.execute_script("window.open('about:blank', 'tab2');")
        driver.switch_to.window('tab2')
        driver.get('https://getnada.com')
        time.sleep(2)
        email = driver.find_element_by_xpath('//*[@id="__layout"]/div/div/div[2]/nav/div/div/ul[2]/li/span').text

        print("Entering email")
        
        driver.switch_to.window(driver.window_handles[0])
        time.sleep(randint(1, 5))
        driver.find_element_by_id('email_reg').send_keys(email)
        time.sleep(2)

        def func():
            pass

        k = 0
        while True:
            if k ==5:
                print("Error")
                return

            try:
                time.sleep(2)
                captchaInput = driver.find_element_by_id('g-recaptcha-response')
                print("captcha found")
                driver.execute_script("arguments[0].setAttribute('style','visibility:visible;');", captchaInput)
                func()
                break

            except:
                k += 1
                driver.find_element_by_class_name('c-pull-right').click()
                time.sleep(10)


        print('Solving captcha...')
        time.sleep(randint(10,15))
        apiKey = '708d155e8050aea34c6c2ca5588a6837'#2captcha api
        siteKey = '6LeTnxkTAAAAAN9QEuDZRpn90WwKk_R1TRW_g-JC'
        pageUrl = 'https://old.reddit.com/register'
        requestUrl = 'https://2captcha.com/in.php?key='+apiKey+'&method=userrecaptcha&googlekey='+siteKey+'&pageurl='+pageUrl
        print('Requesting 2captcha API...')
        resp = requests.get(requestUrl)
        if(resp.text[0:2] != 'OK'):
            print('Service error has occured. Error code: '+resp.text)
            return 
        captchaId = resp.text[3:]
        print('Submitted request successfully, waiting for 35 seconds until requesting return...')
        time.sleep(35)
        returnUrl = 'https://2captcha.com/res.php?key='+apiKey+'&action=get&id='+captchaId
        print('Requesting return...')
        resp = requests.get(returnUrl)
        if resp.text == 'CAPCHA_NOT_READY':
            while resp.text == 'CAPCHA_NOT_READY':
                print('Captcha is not ready, requesting again in 5 seconds...')
                time.sleep(5)
                resp = requests.get(returnUrl)
        elif resp.text[0:5] == 'ERROR':
            print('Service error has occured. Error code: '+resp.text)
            return
        ansToken = resp.text[3:]
        if ansToken == 'OR_CAPCHA_UNSOLVABLE':
            print('Service error has occured. Error code: '+resp.text)
            return
        print('Answer token recieved: '+ansToken)

        # captchaInput = driver.find_element_by_id('g-recaptcha-response')
        # driver.execute_script("arguments[0].setAttribute('style','visibility:visible;');", captchaInput)
        captchaInput.send_keys(ansToken)
        time.sleep(2)
        print('Submitting token')
        #driver.find_element_by_xpath('//*[@id="register-form"]/div[7]/button').click()
        driver.find_element_by_class_name('c-pull-right').click()
        print("Waiting for email")
        time.sleep(10)

        with open('test.txt', 'a+') as f:
            f.write(f'{username} {password}\n')

        # driver.switch_to.window('tab2')

        # time.sleep(25)
        # driver.execute_script("window.scrollTo(0, Y)")
        # time.sleep(2)
        # driver.find_element_by_xpath("//a[contains(text(), 'Verify your Reddit email address')]").click()
        # print("Clicked")
        # while True:
        #     try:
        #         time.sleep(5)
        #         driver.find_element_by_xpath("//a[contains(text(), 'Verify your Reddit email address')]").click()
        #         func()
        #         print('got email')
        #         break
        #         time.sleep(5)

        #     except:
        #         time.sleep(5)
        #         driver.find_element_by_xpath("//a[contains(text(), 'Verify your Reddit email address')]").click()
        #         func()
        #         print('Got email')
        #         break
        #         time.sleep(5)

        # try:
        #     time.sleep(2)
            
        #     wow = driver.find_element_by_xpath("//strong[contains(text(), 'Verify Email Address')]")
        #     print("Can find")
        #     vow = wow.find_element_by_xpath('..')
        #     print("First parent")
        #     vow.find_element_by_xpath('..').click()
        #     print("Second parent")
        #     time.sleep(5)

        # except:
        #     time.sleep(2)
            
        #     wow = driver.find_element_by_xpath("//strong[contains(text(), 'Verify Email Address')]")
        #     print("Found")
        #     vow = wow.find_element_by_xpath('..')
        #     print("First child")
        #     vow.find_element_by_xpath('..').click()
        #     print("Seconf child")
        #     time.sleep(5)

        # time.sleep(15)
        # driver.find_element_by_xpath('/html/body/center/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr[1]/td/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr[3]/td/table/tbody/tr/td/a').click()
        # print("Finally")
        # time.sleep(20)

        driver.delete_all_cookies()

        driver.quit()

    
    except:
        print("Error")
        driver.quit()
        return

q = queue.Queue()

with open('proxy.txt', 'r') as f:
    for line in f.readlines():
        q.put(line)

def main(proxy):
    proxy = proxy
    user, passw = generateUser()
    gets(user, passw, proxy)

n = int(input("Enter the number of accounts: "))
q_s = q.qsize()


my_tr = []

if q_s>=n:

    for _ in range(n):
        prx = q.get()
        t = threading.Thread(target=main, args=(prx,))
        t.start()
        my_tr.append(t)

    for t in my_tr:
        t.join()

else:
    m = int(n/q_s)

    for _ in range(m):
        for _ in range(q_s):
            prx = q.get()
            t = threading.Thread(target=main, args=(prx,))
            t.start()
            my_tr.append(t)

        for t in my_tr:
            t.join()

        with q.mutex:
            q.queue.clear()

        with open('proxy.txt', 'r') as f:
            for line in f.readlines():
                q.put(line)

        my_tr.clear()
           
        time.sleep(randint(3600, 4680))

