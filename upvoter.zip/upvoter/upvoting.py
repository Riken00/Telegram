from seleniumwire import webdriver
from selenium.webdriver.chrome.options import Options
import time, threading
import queue
from random import randint

with open('cred.txt', 'r') as f:
    for line in f.readlines():
        user_v, pass_v = line.split(' ')

class maker:

    def __init__(self, link, username, password, PROXY):
        self.link = link
        self.username = username
        self.password = password
        self.PROXY = PROXY


    def upvote_p(self):


        opt = {'proxy':
        {
            'https':f'socks5://{user_v}:{pass_v}@{self.PROXY}',
            'no_proxy':'localhost,127.0.0.1,dev_server:8080'}
        }

        options = Options()
        options.add_argument("--incognito")
        options.add_argument("start-maximized")
        options.add_argument("--disable-blink-features")
        options.add_argument("--disable-blink-features")
        options.add_argument("--disable-blink-features=AutomationControlled")

        driver = webdriver.Chrome(executable_path='./chromedriver', options=options, seleniumwire_options=opt)
        time.sleep(randint(1,5))
        driver.get('https://old.reddit.com')
        time.sleep(randint(1,5))
        driver.find_element_by_name('user').send_keys(self.username)
        time.sleep(randint(1,5))
        driver.find_element_by_name('passwd').send_keys(self.password)
        time.sleep(randint(5,10))
        try:
            driver.find_element_by_class_name('btn').click()
            time.sleep(1)
        except:
            pass

        driver.execute_script("window.open('about:blank', 'tab2');")
        time.sleep(2)
        driver.switch_to.window('tab2')
        time.sleep(0.5)
        driver.get(self.link)
        time.sleep(randint(5, 10))
        driver.find_element_by_css_selector('div.arrow:nth-child(1)').click()
        #driver.find_element_by_class_name('arrow up')
        time.sleep(randint(1, 5))

        driver.delete_all_cookies()
        driver.quit()
    
    def upvote_c(self):
        opt = {'proxy':
        {
            'https':f'socks5://{user_v}:{pass_v}@{self.PROXY}',
            'no_proxy':'localhost,127.0.0.1,dev_server:8080'}
        }

        options = Options()
        options.add_argument("--incognito")
        options.add_argument("start-maximized")
        options.add_argument("--disable-blink-features")
        options.add_argument("--disable-blink-features")
        options.add_argument("--disable-blink-features=AutomationControlled")

        driver = webdriver.Chrome(executable_path='./chromedriver', options=options, seleniumwire_options=opt)
        driver.get('https://old.reddit.com')
        time.sleep(randint(1,5))
        driver.find_element_by_name('user').send_keys(self.username)
        time.sleep(randint(1,5))
        driver.find_element_by_name('passwd').send_keys(self.password)
        time.sleep(randint(5, 10))
        try:
            driver.find_element_by_class_name('btn').click()
            time.sleep(1)
        except:
            pass

        driver.execute_script("window.open('about:blank', 'tab2');")
        time.sleep(2)
        driver.switch_to.window('tab2')
        time.sleep(0.5)
        driver.get(self.link)
        time.sleep(randint(1, 5))
        driver.find_element_by_css_selector('div.arrow:nth-child(1)').click()
        time.sleep(3)

        driver.delete_all_cookies()
        driver.quit()

def main(col, link, username, password, PROXY):
    clast = maker(link, username, password, PROXY)

    if col == 1:
        clast.upvote_p()

    if col == 2:
        clast.upvote_c()

def q_putter():

    q = queue.Queue()

    with open('proxy.txt', 'r') as f:
        for line in f.readlines():
            q.put(line)
    return q
def q_p_putter():
    q_p = queue.Queue()

    with open('test.txt', 'r') as f:
        for line in f.readlines():
            q_p.put(line)
    return q_p

col = int(input("Enter 1 for post and 2 for comment: "))
vnk = input("Enter the link")
# num = int(input("How many upvotes?: "))

link = vnk.replace("https://www", "https://old")
q = q_putter()
q_s = q.qsize()
# print(q_s,'-------------q size',num,'-------------num')

q_p = q_p_putter()
q_p_s=  q_p.qsize()

print(q_p_s,'***********************')




m = int(q_p_s/q_s)
print(m,'---------------------- m')
my_tr = []
count = 0
for iii in range(m):
    for _ in range(q_s):
        prx = q.get()
        val = q_p.get()
        username, password = val.split(' ')
        t = threading.Thread(target=main, args=(col, link, username, password, prx))
        t.start()
        my_tr.append(t)
        count+=1
        print('------------->  count : ',count)

    for t in my_tr:
        t.join()

    with q.mutex:
        q.queue.clear()

    with open('proxy.txt', 'r') as f:
        for line in f.readlines():
            q.put(line)

    my_tr.clear()
        
    time.sleep(10)







# count = 0
# my_tr = []
# for ii in range(q_p_s):
#     for ie in range(q_s):
#     prx = q.get()
#     # prx = 
#     val = q_p.get()
#     username, password = val.split(' ')
#     t = threading.Thread(target=main, args=(col, link, username, password, prx))
#     t.start()
#     my_tr.append(t)
#     count +=1 
#     if count == proxy_number:
#         count = 0
#         q = q_putter()
#     for t in my_tr:
#         t.join()






# my_tr = []

# if q_s>=num:

#     for _ in range(num):
#         prx = q.get()
#         # prx = 
#         val = q_p.get()
#         username, password = val.split(' ')
#         t = threading.Thread(target=main, args=(col, link, username, password, prx))
#         t.start()
#         my_tr.append(t)

#     for t in my_tr:
#         t.join()

# else:
#     m = int(num/q_s)

#     for _ in range(m):
#         for _ in range(q_s):
#             prx = q.get()
#             val = q_p.get()
#             username, password = val.split(' ')
#             t = threading.Thread(target=main, args=(col, link, username, password, prx))
#             t.start()
#             my_tr.append(t)

#         for t in my_tr:
#             t.join()

#         with q.mutex:
#             q.queue.clear()

#         with open('proxy.txt', 'r') as f:
#             for line in f.readlines():
#                 q.put(line)

#         my_tr.clear()
           
#         time.sleep(360)